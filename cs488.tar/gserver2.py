#!/usr/bin/python

#imports for led
import gpiozero
import time
from gpiozero import TonalBuzzer
# first of all import the socket library
from gpiozero.tones import Tone
from time import sleep
import socket
import copy


# next create a socket object
server = socket.socket()
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
print ("Socket successfully created")

# reserve a port on your computer in our
# case it is 12345 but it can be anything
port = 30000


# '' represents INADDR_ANY, which is used to bind to all interfaces,
server.bind( ('', port) )
print ("socket bound to %s" %(port))

# put the socket into listening mod
server.listen(5)
print ("socket is listening")

# a forever loop until we interrupt it or
# an error occurs

ILLEGAL = "greetings do not match -  rejecting connection"

GREETING = "Bonjour"
ACCEPT = "Greetings"

#
LED="LED"
SOUND="SOUND"
LIGHT="LIGHT"
SONG="SONG"

LEDBLINK_PULSESTATUS = 0 #start at 0

#old mac
v1 = ["G4", 1, "G4", 1, "G4", 1, "D4", 1, "E4", 1, "E4", 1, "D4", 2]
v2 = ["B4", 1, "B4", 1, "A4", 1, "A4", 1, "G4", 3]
v6 = ["D4",1,"G4",1,"G4",1,"G4",1,"D4",1,"E4",1,"E4",1,"D4",2,"B4",1,"B4",1,"A4",1,"A4",1,"G4",2,"D4",1,"D4",1,"G4",1,"G4",1,"G4",1,"D4",1,"D4",1,"G4",1,"G4",1,"G4",2]
v7 = ["G4",1,"G4",1,"G4",1,"G4",1,"G4",1,"G4",1,"G4",1,"G4",1,"G4",1,"G4",1,"G4",1,"G4",1]
song_1rate = 0.25
song_1 = [v1,v2,v6,v7]
#, {"is_blinking": False}
#led1blinking = False
#led2blinking = False
#(17, LED, "RED", led1blinking)
resources =  {
"LED_1":(17,LED,"Red LED", {"is_blinking": False}),
"LED_2":(18,LED,"Green LED",{"is_blinking":False}),
"song_1":(4,SONG,"OldMacDonald",song_1,song_1rate)
# "song_2":(4,SONG, "RowRowBoat")
}
#How to incorporate the MUSIC?!
#Old Macdonald

song_1rate = 0.25

v3 = ["C4", 1, "C4", 1, "C4", 1, "D4", 1, "E4", 1, "E4", 1, "D4", 1]
v4 = ["E4", 1, "F4", 1, "G4", 2, "C4", 1, "C4", 1, "G4", 1, "G4", 1, "G4", 1, "E4", 1, "E4", 1, "E4", 1, "C4", 1, "C4", 1, "C4", 1]
v5 = ["G4", 1, "F4", 1, "E4", 1, "D4", 1, "C4", 1]
song_2 = [v3,v4,v5]
song_2rate = 0.25


#LED_1 = gpiozero.LED(resources["LED_1"])

# From Slides
def init():
	for i in resources:
		type = resources[i][1]
		pin = resources[i][0]
		if type == LED:
			globals()[i] = gpiozero.PWMLED(pin)
			globals()[i].off()
		if type == SONG:
			globals()[i] = TonalBuzzer(pin)

def send_invalid(command):
        error_message  = "Invalid Command received (" + command + ")"
        client.send(error_message.encode() )
# From slides
def send_resources():
        # client.send("The following resources are available:\n".encode())
        listing = "The following resources are available:\n"
        for item in resources:
                listing = listing + "   " + item + " - "
                # details = resources[item]
                type = resources[item][1]
                desc = resources[item][2]
                if type == LED:
                        listing = listing + "(LED) - "
                if type == SOUND:
                        listing = listing + "(SOUND) - "
                listing = listing + desc + "\n"
        client.send(listing.encode())
def send_server():
        hostname = socket.gethostname()
        IPAddr = socket.gethostbyname(hostname)

        response = ("You are connected to: " + hostname)
        client.send(response.encode())
        return(0)

def send_pong():
        client.send("pong".encode())
        return(0)
def send_owner():
        client.send("Aaron".encode())
        return(0)
def process_greeting(client):
        data = client.recv(1024).decode()
        if (data == GREETING):
                client.send(ACCEPT.encode())
                return(0)
        else:
                client.send(ILLEGAL.encode() )
                return(-1)
#Led
def led_on():
        LED_1.on()
        response = "LED on command processed"
        LEDBLINK_PULSESTATUS = 0 #start at 0
        client.send(response.encode())

def led_off():
        LED_1.off()
        response = "LED off command processed"
        LEDBLINK_PULSESTATUS = 0 #start at 0
        client.send(response.encode())
#def do_blink(data):
#	print( globals() )
#	parts = data.split()
#	print(parts[1])
#	if len(parts) == 1:
#		client.send("Error: Invalid Syntax, must specify a resource".encode()) #in this case that its just a blink command
#		return(-1)
#	if [parts[1]]:
#		globals()[parts[1]].blink() #blink this resource
#		client.send("OK".encode()) #send ok
#		return(0)
def do_blink(data): #checks the word after the command if LED
	parts = data.split() #split our data parts
	if len(parts) == 1: #if length of parts list is equal to 1 (just a command) 
		client.send("Error: Invalid syntax, must specify a resource".encode()) #in this case it justs a blink command
		return(-1)
	else:
		if parts[1] in resources: #check if parts[1] (the thing after the command is in resources
			#print(parts[1])
			if resources[parts[1]][1] == LED:
				globals()[parts[1]].blink()
				client.send("OK".encode())
				resources[parts[1]][3]["is_blinking"] = True #set blinking var to true 
				#LEDBLINK_PULSESTATUS = 1
				return 0
			else:
				client.send("Must be an LED resource".encode())
				return(-1)
		else:
			temp = "Error: " + parts[1] + " not defined"
			client.send(temp.encode())
			return(-2)

def do_pulse(data):
	parts = data.split()
	if len(parts) == 1:
		client.send("Error: Invalid syntax, must specify a resource".encode())
		return(-1)
	else:
		if parts[1] in resources: #checks if parts[1] (the thing after the command is in resources
			if resources[parts[1]][1] == LED: #checking if the type is LED
				globals()[parts[1]].pulse()
				client.send("OK".encode())
				#LEDBLINK_PULSESTATUS = 1
				#print(LEDBLINK_PULSESTATUS)
				resources[parts[1]][3]["is_blinking"] = True #set blinking var to true
				return(0)
			else:
				client.send("Must be an LED resource".encode())
				return(-1)
		else:
			temp = "Error: " + parts[1] + " not defined"
			client.send(temp.encode())
			return(-2)
#turn on routine/function
def turn_on(data):
        parts = data.split()
        if len(parts) == 1:
                client.send("Error: Invalid syntax, must specify a resource".encode())
                return(-1)
        else:
                if parts[1] in resources: #checks if parts[1] (the thing after the command is in resources
                        if resources[parts[1]][1] == LED: #checking if the type is LED
                                globals()[parts[1]].on() #turn it on
                                client.send("OK".encode())
                                #LEDBLINK_PULSESTATUS = 0
                                resources[parts[1]][3]["is_blinking"] = False #set blinking var to false
                                return(0)
                        else:
                                client.send("Must be an LED resource".encode())
                                return(-1)
                else:
                        temp = "Error: " + parts[1] + " not defined"
                        client.send(temp.encode())
                        return(-2)
def turn_off(data):
        parts = data.split()
        if len(parts) == 1:
                client.send("Error: Invalid syntax, must specify a resource".encode())
                return(-1)
        else:
                if parts[1] in resources: #checks if parts[1] (the thing after the command is in resources
                        if resources[parts[1]][1] == LED: #checking if the type is LED
                                globals()[parts[1]].off() #turn it off
                                client.send("OK".encode())
                                #LEDBLINK_PULSESTATUS = 0
                                resources[parts[1]][3]["is_blinking"] = False #set blinking var to true
                                return(0)
                        else:
                                client.send("Must be an LED resource".encode())
                                return(-1)
                else:
                        temp = "Error: " + parts[1] + " not defined"
                        client.send(temp.encode())
                        return(-2)
def status(data):
        parts = data.split()
        if len(parts) == 1:
                client.send("Error: Invalid syntax, must specify a resource".encode())
                return(-1)
        else:
                if parts[1] in resources: #checks if parts[>
                        if resources[parts[1]][1] == LED:
                                  if resources[parts[1]][3]["is_blinking"] == True: #checking if true:
                                        print("undetermined")
                                        client.send("UNDETERMINED".encode())
                                        return(0)
                                  elif globals()[parts[1]].value == 1:
                                        client.send("ON".encode())
                                        return(-1)
                                  elif globals()[parts[1]].value == 0:
                                        client.send("OFF".encode())
                                        return(-2)
                        else:
                                client.send("Must be an LED resource".encode())
                                return(-3)
                else:
                        temp = "Error: " + parts[1] + " not defined"
                        client.send(temp.encode())
                        return(-4)
#play a song
def playSong(data):
	parts = data.split()
	if len(parts) == 1:
		client.send("Error: Invalid syntax, must specify a resource along with the command!".encode())
		return(-1)
	else:
		if parts[1] in resources: #checks if the resource requested is in the resources list
			if resources[parts[1]][1] == SONG: #checks if it is of song type
				playingsong = copy.deepcopy(resources[parts[1]][3]) #the notes/verses of the song in a list, deep copy of the list
				print(playingsong)
				playingrate = resources[parts[1]][4] #the specialized rate of song which is a global variable
				print(playingrate)
				client.send(f"Playing | {resources[parts[1]][2]}".encode()) 
				for index, verse in enumerate(playingsong):
					print("Index: ",index, "***!!!**",verse)
					for i in range(0, len(verse),2):
						note = verse[i]
						print("***********",note)
						globals()[parts[1]].play(note)
						sleep(playingrate*verse[i+1]) #how do I specialize the verse, rate for each song?
						globals()[parts[1]].stop()
						sleep(0.1)
				#client.send(f"Song completed: {resources[parts[1]][2]}".encode())
				return(-1)
			else:
				client.send("Playing | Must be a SONG resource in order to play a song. The resource provided is not a SONG".encode())
				return(-1)
		else:
			temp = "Error: " + parts[1] + " not defined"
			client.send(temp.encode())
			return(-2)
def playSong2(data):
	parts = data.split()
	if len(parts) == 1:
		client.send("Error: Invalid Syntax, must specify a resource".encode())
		return(-1)
	elif globals().get(parts[1]) is None or resources[part[1]][1] !=4:
		client.send("Error: Invalid Resource, must specify a real song".encode())
		return(-1)
	client.send("Playing".encode())
	for verse in old_mac:
		for i in range(0, len(verse), 2):
			note = verse[i]
			globals()[parts[1]].play(note)
			sleep(rate*verse[i+1])
			globals()[parts[1]].stop()
			sleep(0.1)
	return(0)

def process_client(data,addr):
	# init()
	while (data):
                stuff = data.split()
                command = stuff[0] #command

                match command.lower(): #lowercase so cases don't matter

                        case "close":
                                client.send("bye-bye".encode())
                                client.close()
                                print("Connection closed:",addr)
                                return(-1)
                        case "server":
                                send_server()
                        case "resources":
                                send_resources()
                        case "ping":
                                send_pong()
                        case "owner":
                                send_owner()
                        case "blink":
                                do_blink(data)
                        case "led_on":
                                led_on()
                        case "led_off":
                                led_off()
                        case "blink":
                                do_blink(data)
                        case "pulse":
                                do_pulse(data)
                        case "turnon":
                                turn_on(data)
                        case "turnoff":
                                turn_off(data)
                        case "status":
                                status(data)
                        case "play":
                                playSong(data)
                        case _:
                                send_invalid(data)

                data = client.recv(1024).decode()

init()
#while(True):
 #       client,addr = server.accept()
  #      print ("Got connection from:",addr)
  #      rc = process_greeting(client)

   #     if rc == -1:
   #             client.close()
   #             continue

  #      rc = 0
  #      while (rc == 0 ):
  #              data = client.recv(1024).decode()

  #              rc = process_client(data,addr)
