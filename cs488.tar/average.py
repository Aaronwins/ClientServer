#!/usr/bin/python
test1 = 90
test2 = 88
test3 = 95

average = (test1 + test2 + test3)/3
print("My average is: ",average)
