#!/usr/bin/python

# Import socket module
import socket
import sys
#import for LED 
import gpiozero
import time

led1 = gpiozero.LED(17) #pin 17

if len(sys.argv)  == 1: #only thing is the name of the program  ARGV[] 
#0-Name
#1-pi-200
#2-the something else
	data_to_send = ""
else:
	host = sys.argv[1]

# Create a socket object
server = socket.socket()

# Define the port on which you want to connect
port = 30000

# connect to the server on local computer
server.connect((host, port))

# receive data from the server and decoding to get the string.
#this is an standardized protocol for all of the client/servers
GREETING = "Bonjour"
ACCEPT = "Greetings"


def sendgreeting():
	server.send(GREETING.encode()) #encode
	answer = server.recv(1024).decode() 

	print ("Sent: ",GREETING,"returned: ",answer) #SENT BONJOUR RETURN GREETINGS

	if answer == ACCEPT:
		return(0)
	else:
		print("Error - received bad response to greeting: ")
		return(-1)

def get_server(stuff,server):
	server.send("server".encode())
	answer = server.recv(1024).decode() 
	print(answer)
	return(0)
def get_resources(stuff,server):
        server.send("resources".encode())
        answer = server.recv(1024).decode()
        print(answer)
        return(0)

def send_close(stuff, server):
	server.send(stuff.encode()) 
	answer = server.recv(1024).decode()
	print(answer)
	return(-1) #return -1

def get_ping(stuff,server):
	server.send("ping".encode())

	answer = server.recv(1024).decode() #waits for an answer back
	print(answer)

def get_Owner(stuff, server):
	server.send("owner".encode()) #send the owner input
	answer = server.recv(1024).decode() #waits for an answer back
	print("The owner of this pi is: " + answer)
#function to turn LEDon
def get_LEDon(stuff,server):
	server.send("LED.on".encode()) #send the LED.on to turn the led on 
	answer = server.recv(1024).decode() #wait for an answer
	print(answer)
#function to turn LEDoff
def get_LEDoff(stuff,server):
	server.send("LED.off".encode()) #send the LED.off to turn off 
	answer = server.recv(1024).decode() #waits for an answer 
	print(answer)

# upon  startup  we send a greeting to the server

rc  = sendgreeting()

#while true
while (rc == 0):
	stuff = input(">> ") #prompt for input

	match stuff: #what is match in this case?

		case "close":
			send_close(stuff,server)
			rc = -1

		case "server":
			get_server(stuff,server)
		case "resources":
			get_resources(stuff, server)
		case "ping":
			get_ping(stuff,server)
		case "owner":
			get_Owner(stuff,server)
		case "LED.on":
			get_LEDon(stuff,server)
		case "LED.off":
			get_LEDoff(stuff,server)
		case _:
			print("Sorry, Invalid command")


server.close()
