#!/usr/bin/python

# first of all import the socket library
import socket

#import the LED libraries needed 
import gpiozero
import time

led1 = gpiozero.LED(17)
led2 = gpiozero.LED(18)

# next create a socket object
server = socket.socket()
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
print ("Socket successfully created")

# reserve a port on your computer in our
# case it is 12345 but it can be anything
port = 30000


# '' represents INADDR_ANY, which is used to bind to all interfaces,
server.bind( ('', port) )
print ("socket bound to %s" %(port))

# put the socket into listening mod
server.listen(5)
print ("socket is listening")

# a forever loop until we interrupt it or
# an error occurs

ILLEGAL = "greetings do not match -  rejecting connection"

GREETING = "Bonjour"
ACCEPT = "Greetings"


LED = 1
SOUND = 2
LIGHT = 3
SONG = 4

#resources =  {"greed_LED":17,
#"red_LED":18,
#"buzzer":4}
resources = {"LED_1":(17, LED, "RED LED"),
"LED_2":(18, LED, "Green LED"), "song_1":(4, SONG, "Mary had a little lamb")}


def init():
	for i in resources:
		type = resources[i][1]
		pin = resources[i][0]

		if type == LED:
			globals()[i] = gpiozero.PWNLED(pin)
			globals()[i].off()
		if type == SONG:
			globals()[i] = TonalBuzzer(pin)
def send_invalid(command):
	error_message = "Invalid Command recieved(" + command + ")"
	client.send(error_message.encode() )
def send_resources():
	# client.send("The following resources are available:\n".encode())
	listing = "The following resources are available:\n"
	for item in resources:
		listing = listing + "   " + item + " - "
		# details = resources[item]
		type = resources[item][1]
		desc = resources[item][2]
		if type == LED:
			listing = listing + "(LED) - "
		if type == SOUND:
			listing = listing + "(SOUND) - "
		listing = listing + desc + "\n"
	client.send(listing.encode())

def send_server():
	hostname = socket.gethostname()
	IPAddr = socket.gethostbyname(hostname)

	response = ("You are connected to: " + hostname)
	client.send(response.encode()) #send a response back 
	return(0)
def send_pong():
	client.send("pong".encode())
	return(0)

def send_owner(): #send who is the owner of this server
	client.send("Aaron".encode())
	return(0)

def send_LEDon(): #send by turning led1 ON
	led1.on()
	client.send("Ok".encode())
	return(0)

def send_LEDoff(): #send by turning led1 OFF
	led1.off()
	client.send("Ok".encode())
	return(0)

def process_greeting(client):
	data = client.recv(1024).decode()
	if (data == GREETING):
		client.send(ACCEPT.encode()) #send back the greetings 
		return(0)
	else:
		client.send(ILLEGAL.encode() ) #ILLEGAL not going to accept the connections
		return(-1)


#process client,parameters: data that was sent and the address
def process_client(data,addr):

	while (data):


		match data:

			case "close":
				client.send("bye-bye".encode())
				client.close()
				print("Connection closed:",addr)
				return(-1)

			case "server":
				send_server() #send server routine

			case "ping":
				send_pong()
			case "owner":
				send_owner()
			case "LED.on":
				send_LEDon()
			case "LED.off":
				send_LEDoff()
			case _:
				send_invalid(data)




		data = client.recv(1024).decode()
while(True):
	client,addr = server.accept() #accept message from the client
	print ("Got connection from:",addr) #print message on server 
	rc = process_greeting(client) #process the greeting

	if rc == -1: #close the connection
		client.close()
		continue

	rc = 0
	while (rc == 0 ): #waiting for commands from client
		data = client.recv(1024).decode()

		rc = process_client(data,addr)
