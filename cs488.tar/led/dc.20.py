#!/usr/bin/python

import gpiozero
import time

led1 = gpiozero.LED(17)
led2 = gpiozero.LED(18)

#led.blink()
#	led.on()
#	time.sleep(1)
#	led.off()
#	time.sleep(1)
	#if led.is_lit: #is lit?
	#	led.off() #turn off
	#else: 
	#	led.on() #else turn on
	#time.sleep(1)
led1.blink()
time.sleep(1)
led2.blink()

while True:
	continue
