#!/usr/bin/python
import gpiozero
from gpiozero import TonalBuzzer
from gpiozero.tones import Tone
from time import sleep

t = TonalBuzzer(4) 

v1 = ["C4", 1, "C4", 1, "C4", 1, "D4", 1, "E4", 1, "E4", 1, "D4", 1]
v2 = ["E4", 1, "F4", 1, "G4", 2, "C4", 1, "C4", 1, "C4",1, "G4", 1,"G4", 1, "G4", 1,"E4", 1, "E4",1,"E4",1,"C4",1,"C4",1,"C4",1]
v3 = ["G4", 1, "F4", 1, "E4", 1, "D4", 1, "C4", 1]
#buzzer = gpiozero.TonalBuzzer(4) #on pin four 

#notes = ["C4","D4", "E4", "F4", "G4", "A4", "B4", "C5"]

song = [v1,v2, v3]
rate = 0.25

for verse in song:
	for i in range(0, len(verse),2):
		note = verse[i]
		t.play(note)
		sleep(rate* verse[i+1])
		t.stop()
		sleep(0.1)

#for note in notes: 
#	buzzer.play(note)
#	time.sleep(0.5)
#buzzer.stop()
