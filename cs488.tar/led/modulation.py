#!/usr/bin/python

import gpiozero 
import time 

led = gpiozero.PWMLED(17)

led.pulse()

while True: 
	continue

