#!/usr/bin/python

import gpiozero
import time

buzzer = gpiozero.TonalBuzzer(4) #on pin four 

notes = ["C4","D4", "E4", "F4", "G4", "A4", "B4", "C5"]

for note in notes: 
	buzzer.play(note)
	time.sleep(0.5)
buzzer.stop()
