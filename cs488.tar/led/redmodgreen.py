#!/usr/bin/python

import gpiozero
import time

led1 = gpiozero.PWMLED(17)
led2 = gpiozero.PWMLED(18)


led1.pulse(fade_out_time=2, fade_in_time=2,n=1)
time.sleep(4)
led2.on()

while True:
	continue

