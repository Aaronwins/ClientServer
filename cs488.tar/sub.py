#!/usr/bin/python

import paho.mqtt.client as mqtt
import time
import gpiozero
from typing import Callable


LED = 1
SONG = 4

PI_NAME = 'pi-7'
NEXT_PI_NAME = 'pi-14'

resources: dict[str, tuple[str, int, str]] =  {
    'LED_1': (17, LED, 'Red LED'),
}

def start(client, _wait_span):
    client.publish('pace', 'TALXS')
    toggle_led('LED_1')
    time.sleep(3)
    toggle_led('LED_1')
    next_command = NEXT_PI_NAME + ' pulse 5'
    client.publish(globals()['topic'], next_command)

def pulse(client, wait_span):
    pulse_led('LED_1', 1)
    time.sleep(wait_span)
    next_command = NEXT_PI_NAME + ' blink 5'
    client.publish(globals()['topic'], next_command)
   
def blink(client, wait_span):
    blink_led('LED_1', 1)
    time.sleep(wait_span)
    next_command = NEXT_PI_NAME + ' end'
    client.publish(globals()['topic'], next_command)
 
def end(client, _wait_span):
    toggle_led('LED_1')
    time.sleep(5)
    toggle_led('LED_1')
    client.publish('pace', 'TALXS')


commands: dict[str, tuple[str, Callable]] = {
    'start': (
        'Requests server to start the connection',
        start,
    ),
    'blink': (
        'Requests server to blink next pi\'s led',
        blink,
    ),
    'pulse': (
        'Requests server to pulse next pi\'s led',
        pulse,
    ),
    'end': (
        'Requests server to end the connection',
        end,
    ),
}

# Define callback functions
def on_connect(client, userdata, flags, rc):
        print("Connected with result code "+str(rc))
# Subscribe to a topic when connected
        while True:
                topic = input("What topic ? ('done' to exit): ")
                if topic == "done":
                    return()
                else:
                    globals()['topic'] = topic
                    client.subscribe(topic)

def on_message(client, userdata, msg):
        message: str = str(msg.payload.decode())
        split_message = message.split(' ')

        pi_name = split_message[0] if len(split_message) > 0 else ''
        command = split_message[1] if len(split_message) > 1 else ''
        wait_span = int(split_message[2]) if len(split_message) > 2 else ''

        print(message)
        if (pi_name == PI_NAME):
            if command in commands.keys():
                commands[command][1](client, wait_span)

def toggle_led(led):
    globals()[led].toggle()

def blink_led(led, wait_span):
    globals()[led].blink(wait_span, wait_span)

def pulse_led(led, wait_span):
    globals()[led].pulse(wait_span, wait_span)

def init():
    for i in resources:
        type = resources[i][1]
        pin = resources[i][0]

        if type == LED:
            globals()[i] = gpiozero.PWMLED(pin)
            print('Initialized LED', pin, i)
        elif type == SONG:
            globals()[i] = gpiozero.TonalBuzzer(pin)
            print('Initialized Buzzer', pin, i)

init()
#
#
# Main Code
#
# Create an MQTT client instance
client = mqtt.Client()

# Assign callback functions
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker running on localhost
client.connect("192.168.1.200", 1883, 60) #(name of host, port, seconds til exiting if no response)

# Start the loop to process incoming messages
client.loop_forever()