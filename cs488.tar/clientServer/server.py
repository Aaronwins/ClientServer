#!/usr/bin/python

import socket

#next create a socket object

s=socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) #set socket to be reusable addresses to avoid timeouts
print("Socket successfully created")

#reserve a port on your computer 

port = 12345 #port is the thing that you listen to 


# Next bind to the port 

s.bind(('', port)) #listen on any address connect IP Address to the port (that's where we will listen) 
print("socket bound to %s" %(port)) 

#put the socket into listening mode 
s.listen(5)
print("socket is listening")

while True:
	c,addr = s.accept() #sit there until a message gets sent to it
	#c,addrreturns socket object and address
	print("Got connection from: ", addr)

	data = c.recv(1024).decode() #data transfers in bytes convert to characters

	if data=="close":
	   c.close()
	   break
	data="You Sent:"+data 
	c.send(data.encode()) #send it back to the client	
