#!/usr/bin/python

#import socket module
import socket
import sys

#argv is all the arguments that are passed to the python program
#if len(sys.argv) == 1:
 #       data_to_send = "DEFAULT"
#else:
#       data_to_send = " ".join(sys.argv[1:])

#create a socket object
s = socket.socket()

#Define the port on which you want to connect
port = 12345

#connect to the server on local computer
s.connect(('pi-7',port)) #socket.connect, list of host name, port

#send/recieve data from the server and decoding to
#s.send(data_to_send.encode()) we are not sending data in this case

data = s.recv(1024).decode() #recieve back from whatever is in the socket

print(data)
