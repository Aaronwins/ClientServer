#!/usr/bin/python


import socket
import random
#next create a socket object

s=socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) #set socket to be reusable addresses to avoid timeouts
print("Socket successfully created")

#reserve a port on your computer 

port = 12345 #port is the thing that you listen to 

# Next bind to the port 

s.bind(('', port)) #listen on any address connect IP Address to the port (that's where we will listen) 
print("socket bound to %s" %(port)) 

#put the socket into listening mode 
s.listen(5)
print("socket is listening")

while True:
	log = open("/home/student/jokesFolder/joker.log","a") #added this
	c,addr = s.accept() #sit there until a message gets sent to it
	#c,addrreturns socket object and address
	print("Got connection from: ", addr)
	#data = c.recv(1024).decode() #data transfers in bytes convert to characters
	#if data=="close":
	 #  c.close()
	 #  break
	#data="You Sent:"+data
	#c.send(data.encode()) #send it back to the client
	randNumber = (random.randint(1,3))
	fileJoke = "jokes-" + str(randNumber) + ".txt"
	joke_file = open("/home/student/jokesFolder/"+fileJoke, "r") #joke file reading
	line = joke_file.readline()
	joke_string = "Joke of the Day:"
	while (line): 
		print("Line just sent to the client: " + line.strip())
		joke_string += "\n" + "\t" + line.strip()
		line = joke_file.readline()
	c.send(joke_string.encode())
	message = "New Connection from: " + str(addr) + "- sending jokes:" + str(randNumber)+ "\n"
	log.write(message)
	joke_file.close() #close file
	log.close() #close the log
	c.close() #closes the connection "C"
