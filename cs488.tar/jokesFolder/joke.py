#!/usr/bin/python

import random


randNumber = (random.randint(1,3))

fileJoke = "jokes-" + str(randNumber) + ".txt"

joke_file = open("/home/student/jokesFolder/"+fileJoke,"r") #joke file

line = joke_file.readline()

while(line): #while line is true
	print(line.strip())
	line = joke_file.readline()
joke_file.close() #close file
