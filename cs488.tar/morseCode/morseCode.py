#!/usr/bin/python
import gpiozero
import time

led1 = gpiozero.LED(17,active_high=False) #LED connected to GPIO pin 17, active low

#dot function
def dot(dotDelay=0.3, betweenDelay=0.1):
    led1.on()
    time.sleep(dotDelay) #0.3 dot delay
    led1.off()
    time.sleep(betweenDelay) #0.1 second delay between dots and dashes

#dash function
def dash(dashDelay = 1, betweenDelay=0.1):
    led1.on()
    time.sleep(dashDelay) #1 second dash delay
    led1.off()
    time.sleep(betweenDelay) #0.1 second delay between dots and dashes

# The Letter P
dot()
dash()
dash()
dot()

time.sleep(2)  # Pause between letters

# Letter A
dot()
dash()

time.sleep(2)  # Pause between letters

# Letter C
dash()
dot()
dash()
dot()

time.sleep(2)  # Pause between letters

# Letter E
dot()

led1.off() #turn the LED off
