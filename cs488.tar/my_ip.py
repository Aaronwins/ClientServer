#!/usr/bin/python
import os

pi = os.environ.get("SSH_CONNECTION").split()
print("Aaron's IP address is: ", end ="")
print(pi[2])
