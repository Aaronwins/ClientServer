import paho.mqtt.client as mqtt

# Define callback function for on_publish event
def on_publish(client, userdata, mid):
	print("Message published.")

#
# Main Code
#
#
# Create an MQTT client instance
client = mqtt.Client()

# Assign callback function for on_publish event
client.on_publish = on_publish

# Connect to the MQTT broker running on localhost
#client.connect("localhost", 1883, 60)
client.connect("192.168.1.200", 1883, 60)
# Publish a message to the topic "test/topic"

topic = input("What topic would you like to publish to: ")

# topic = "topic"
print()
while True:
	message = input("Enter message ('done' to terminate): ")
#message = "Hello, MQTT!"
	if message == "done":
		break
	else:
		client.publish(topic, message)
# Disconnect from the MQTT broker
client.disconnect()
