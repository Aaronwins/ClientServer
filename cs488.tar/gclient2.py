#!/usr/bin/python

# Import socket module
import socket
import sys


#imports for led
import gpiozero
import time


if len(sys.argv)  == 1:
        data_to_send = ""
else:
        host = sys.argv[1]

# Create a socket object
server = socket.socket()

# Define the port on which you want to connect
port = 30000

# connect to the server on local computer
server.connect((host, port))

# receive data from the server and decoding to get the string.

GREETING = "Bonjour"
ACCEPT = "Greetings"

#
def get_resources(stuff,server):
        server.send("resources".encode())
        answer = server.recv(1024).decode()
        print(answer)
        return(0)
def send_blink(stuff,server):
	server.send(stuff.encode())
	answer = server.recv(1024).decode()
	print(answer)
def send_pulse(stuff, server):
	server.send(stuff.encode())
	answer = server.recv(1024).decode()
	print(answer)
def send_turnon(stuff,server):
	server.send(stuff.encode())
	answer = server.recv(1024).decode()
	print(answer)
def send_turnoff(stuff,server):
	server.send(stuff.encode())
	answer = server.recv(1024).decode()
	print(answer)
def send_statusRequest(stuff,server):
        server.send(stuff.encode())
        answer = server.recv(1024).decode()
        print(answer)
def send_song(stuff,server):
        server.send(stuff.encode())
        answer = server.recv(1024).decode()
        print(answer)
def sendgreeting():
        server.send(GREETING.encode())
        answer = server.recv(1024).decode()

        print ("Sent: ",GREETING,"returned: ",answer)

        if answer == ACCEPT:
                return(0)
        else:
                print("Error - received bad response to greeting: ")
                return(-1)

def get_server(stuff,server):
        server.send("server".encode())
        answer = server.recv(1024).decode()
        print(answer)
        return(0)

def send_close(stuff, server):
        server.send(stuff.encode())

        answer = server.recv(1024).decode()
        print(answer)

def get_ping(stuff,server):
        server.send("ping".encode())

        answer = server.recv(1024).decode()
        print(answer)

#Created in class Owner
def get_owner(stuff,sever):
        server.send("owner".encode())
        answer = server.recv(1024).decode()
        print(answer)

#led
def led_on(stuff, server):
        server.send("led_on".encode())
        answer = server.recv(1024).decode()
        print(answer)


def led_off(stuff, server):
        server.send("led_off".encode())
        answer = server.recv(1024).decode()
        print(answer)



# upon  startup  we send a greeting to the server


rc  = sendgreeting()



while (rc == 0):
        stuff = input(">> ")
        PARTS = stuff.split()


        match PARTS[0]: #command

                case "close":
                        send_close(stuff,server)
                        rc = -1

                case "server":
                        get_server(stuff,server)
                case "resources":
                        get_resources(stuff,server)

                case "ping":
                        get_ping(stuff,server)
                #####
                case "owner":
                        get_owner(stuff,server)
                #led
                case "led_on":
                        led_on(stuff, server)
                case "led_off":
                        led_off(stuff, server)
                case "blink":
                        send_blink(stuff,server) #send full input
                case "pulse":
                        send_pulse(stuff, server) #send full input
                case "turnon":
                        send_turnon(stuff,server)
                case "turnoff":
                        send_turnoff(stuff,server)
                case "status":
                        send_statusRequest(stuff,server)
                case "play":          #play song
                        send_song(stuff,server)
                case _:
                        print("Sorry, Invalid command")

server.close()
